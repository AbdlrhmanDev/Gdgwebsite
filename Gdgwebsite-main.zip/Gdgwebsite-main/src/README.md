# 🌟 Google Developer Group - Future University Website

<div align="center">

![GDG Logo](https://img.shields.io/badge/GDG-Future%20University-4285f4?style=for-the-badge&logo=google&logoColor=white)
![React](https://img.shields.io/badge/React-18-61dafb?style=for-the-badge&logo=react&logoColor=black)
![TypeScript](https://img.shields.io/badge/TypeScript-5-3178c6?style=for-the-badge&logo=typescript&logoColor=white)
![Tailwind CSS](https://img.shields.io/badge/Tailwind%20CSS-4-06b6d4?style=for-the-badge&logo=tailwindcss&logoColor=white)

**موقع ويب احترافي وشامل لمجموعة Google Developer Group**

[العربية](#arabic) • [English](#english) • [دليل البدء السريع](QUICK_START.md) • [نظرة عامة على المشروع](PROJECT_OVERVIEW.md)

</div>

---

## 🚀 مقدمة سريعة

موقع متكامل لإدارة مجتمع Google Developer Group في جامعة المستقبل، مع دعم كامل للغة العربية والإنجليزية، نظام Gamification، لوحات تحليلات متقدمة، وإدارة شاملة للفعاليات والأعضاء.

### ✨ **الميزات الرئيسية**

```
✅ دعم متعدد اللغات (العربية/الإنجليزية) مع RTL/LTR
✅ نظام أدوار ثلاثي (User, Member, Admin)
✅ نظام Gamification كامل (نقاط، مستويات، شارات)
✅ إدارة فعاليات متقدمة مع 6 طرق تسجيل مختلفة
✅ لوحات تحليلات وإحصائيات تفاعلية
✅ 8 أقسام عمل مع نظام مهام شامل
✅ تصميم حديث مع رسوم متحركة متقدمة
✅ وضع داكن/فاتح
✅ تصميم متجاوب بالكامل
```

---

## 📋 جدول المحتويات

- [البدء السريع](#-البدء-السريع)
- [الميزات التفصيلية](#-الميزات-التفصيلية)
- [التقنيات المستخدمة](#️-التقنيات-المستخدمة)
- [هيكل المشروع](#-هيكل-المشروع)
- [الحسابات التجريبية](#-الحسابات-التجريبية)
- [الوثائق](#-الوثائق)
- [التطوير المستقبلي](#-التطوير-المستقبلي)
- [المساهمة](#-المساهمة)
- [الترخيص](#-الترخيص)

---

## 🎯 البدء السريع

### الاستخدام الفوري
الموقع جاهز للاستخدام! ما عليك سوى فتح المتصفح والبدء في الاستكشاف.

### 🔐 حسابات تجريبية

<table>
<tr>
<th>الدور</th>
<th>البريد الإلكتروني</th>
<th>كلمة المرور</th>
<th>الصلاحيات</th>
</tr>
<tr>
<td>🔴 Admin</td>
<td>admin@gdg.com</td>
<td>admin123</td>
<td>صلاحيات كاملة</td>
</tr>
<tr>
<td>🟡 Member</td>
<td>member@gdg.com</td>
<td>member123</td>
<td>لوحة تحكم + Gamification</td>
</tr>
<tr>
<td>🟢 User</td>
<td>user@gdg.com</td>
<td>user123</td>
<td>تصفح أساسي</td>
</tr>
</table>

### ⚡ خطوات سريعة

1. **للمستخدمين العاديين**: تصفح الموقع وشاهد الفعاليات
2. **للأعضاء**: سجل دخول وتابع نقاطك ومهامك
3. **للمدراء**: أدر الفعاليات والأقسام وشاهد التحليلات

📖 **[دليل البدء السريع الكامل](QUICK_START.md)**

---

## 🎨 الميزات التفصيلية

### 🌐 **1. نظام متعدد اللغات**

<details>
<summary>اضغط لعرض التفاصيل</summary>

- ✅ دعم كامل للعربية والإنجليزية
- ✅ تبديل تلقائي لاتجاه النص (RTL/LTR)
- ✅ ترجمة شاملة لجميع واجهات المستخدم
- ✅ حفظ تفضيلات اللغة
- ✅ تنسيق التواريخ والأرقام حسب اللغة

</details>

### 👥 **2. نظام الأدوار والصلاحيات**

<details>
<summary>اضغط لعرض التفاصيل</summary>

#### **🔹 مستخدم عادي (User)**
- تصفح المحتوى والفعاليات
- التسجيل في الفعاليات
- مشاهدة معلومات الفريق

#### **🔹 عضو (Member)**
- جميع صلاحيات المستخدم
- لوحة تحكم شخصية
- نظام Gamification كامل
- إدارة المهام الشخصية
- عرض الإحصائيات

#### **🔹 مدير (Admin)**
- جميع صلاحيات العضو
- لوحة إدارة متقدمة
- إدارة الفعاليات (CRUD)
- لوحة تحليلات شاملة
- إدارة الأقسام والمهام
- عرض تسجيلات الفعاليات

</details>

### 🏆 **3. نظام Gamification**

<details>
<summary>اضغط لعرض التفاصيل</summary>

#### **المكونات الأساسية:**
- 🎯 **النقاط**: نظام نقاط شامل لتتبع النشاط
- 📊 **المستويات**: نظام تقدم من 1 إلى 10+
- 🥇 **الترتيب**: لوحة صدارة تنافسية
- 🎖️ **الشارات**: 20+ شارة قابلة للفتح

#### **أنواع الشارات:**
- 🎯 المشارك النشط (حضور 10 فعاليات)
- 💡 المبتكر (نشر 5 مشاريع)
- 👑 القائد (تنظيم فعالية)
- 🏆 الخبير (الوصول للمستوى 10)
- 📚 المعلم (مساعدة 20 عضو)
- 🤝 المتواصل (الاتصال مع 50 عضو)

#### **الإحصائيات:**
- 📈 رسوم بيانية للتقدم
- 📊 تحليل النشاط الشهري
- 🎯 مقارنة الأداء
- 🏅 تاريخ الإنجازات

</details>

### 📅 **4. إدارة الفعاليات**

<details>
<summary>اضغط لعرض التفاصيل</summary>

#### **أنواع الفعاليات:**
- 🎓 Workshops (ورش عمل)
- 🤝 Meetups (لقاءات)
- 🎤 Conferences (مؤتمرات)
- 💻 Hackathons (هاكاثونات)
- 📚 Study Jams (جلسات دراسية)
- 🎮 Competitions (مسابقات)

#### **طرق التسجيل المدعومة:**
1. **Google Forms** - الأكثر شيوعاً
2. **Typeform** - تصميم عصري
3. **Microsoft Forms** - للمؤسسات
4. **Eventbrite** - للفعاليات الكبرى
5. **Airtable** - إدارة مرنة
6. **Custom** - نماذج مخصصة

#### **الميزات:**
- ✅ فلترة متقدمة (النوع، التاريخ، الحالة)
- ✅ بحث ذكي
- ✅ عرض تفاصيل كاملة
- ✅ تسجيل سريع
- ✅ تذكيرات تلقائية
- ✅ تصدير قوائم الحضور

</details>

### 📊 **5. لوحات التحليلات**

<details>
<summary>اضغط لعرض التفاصيل</summary>

#### **إحصائيات الفعاليات:**
- 📈 عدد الحضور
- 📊 نسب التسجيل
- 🎯 معدلات الإكمال
- 📅 تحليل زمني

#### **إحصائيات الأعضاء:**
- 👥 عدد الأعضاء النشطين
- 📈 نمو المجتمع
- 🎯 معدلات المشاركة
- 🏆 توزيع المستويات

#### **أداء الأقسام:**
- 📊 إنتاجية كل قسم
- ✅ معدلات إنجاز المهام
- 👥 توزيع الأعضاء
- 📈 تحليل الأداء

#### **التصورات البصرية:**
- 📊 رسوم بيانية تفاعلية (Recharts)
- 📈 مخططات دائرية وخطية
- 📉 جداول مقارنة
- 🎨 تصميم احترافي

</details>

### 🏢 **6. نظام الأقسام والمهام**

<details>
<summary>اضغط لعرض التفاصيل</summary>

#### **الأقسام الثمانية:**

| القسم | الأيقونة | المسؤوليات |
|-------|---------|------------|
| 👑 القيادة | Leadership | التنسيق العام وإدارة الفريق |
| 🎉 الفعاليات | Events | تنظيم وتنسيق الفعاليات |
| 💻 التقنية | Technical | الدعم التقني والتطوير |
| 📱 التسويق | Marketing | الحملات والترويج |
| 🎨 التصميم | Design | الجرافيكس والبراندنج |
| 🤝 العلاقات العامة | PR | التواصل والشراكات |
| 💰 المالية | Finance | الميزانية والموارد |
| 👔 الموارد البشرية | HR | التوظيف والتدريب |

#### **إدارة المهام:**
- ✅ إنشاء مهام لكل قسم
- ✅ تحديد الأولوية (عالي، متوسط، منخفض)
- ✅ تعيين المواعيد النهائية
- ✅ تتبع الحالة (Pending, In Progress, Completed)
- ✅ إشعارات المهام
- ✅ تقارير الإنجاز

</details>

---

## 🛠️ التقنيات المستخدمة

### Frontend Framework
```
⚛️ React 18          - مكتبة واجهة المستخدم
🎯 TypeScript        - أمان الأنواع
🎨 Tailwind CSS v4   - إطار عمل التصميم
```

### Libraries & Tools
```
🎭 Motion/React      - الرسوم المتحركة
📊 Recharts          - الرسوم البيانية
🎨 Lucide React      - نظام الأيقونات
🎯 React Hooks       - إدارة الحالة
💾 LocalStorage      - التخزين المحلي
```

### Design System
```
🌈 Google Colors     - نظام الألوان
✨ Glass Effects     - التأثيرات الزجاجية
🎨 Gradients         - المتدرجات اللونية
🎬 Animations        - الرسوم المتحركة
📱 Responsive        - التصميم المتجاوب
```

---

## 📁 هيكل المشروع

```
gdg-future-university/
│
├── 📄 App.tsx                      # المكون الرئيسي
│
├── 📂 components/                  # مكونات React
│   ├── 🏠 Hero.tsx                # القسم الرئيسي
│   ├── ℹ️ About.tsx               # من نحن
│   ├── 📅 Events.tsx              # الفعاليات
│   ├── 👥 Team.tsx                # الفريق
│   ├── 📧 Contact.tsx             # تواصل معنا
│   ├── 🦶 Footer.tsx              # التذييل
│   ├── 🧭 Navigation.tsx          # شريط التنقل
│   │
│   ├── 🔐 Auth/                   # المصادقة
│   │   ├── Login.tsx
│   │   └── Register.tsx
│   │
│   ├── 🎛️ Dashboards/            # لوحات التحكم
│   │   ├── AdminPanel.tsx
│   │   ├── UserDashboard.tsx
│   │   ├── GamificationDashboard.tsx
│   │   ├── AnalyticsDashboard.tsx
│   │   ├── TasksPanel.tsx
│   │   └── DepartmentsPanel.tsx
│   │
│   └── 🎨 ui/                     # مكونات UI
│       ├── button.tsx
│       ├── card.tsx
│       ├── badge.tsx
│       ├── input.tsx
│       └── ... (70+ components)
│
├── 📂 lib/                         # المكتبات المساعدة
│   ├── i18n.ts                    # نظام الترجمة
│   ├── storage.ts                 # إدارة التخزين
│   ├── departments.ts             # إدارة الأقسام
│   └── registration-methods.ts    # طرق التسجيل
│
├── 📂 styles/                      # الأنماط
│   └── globals.css                # CSS العامة
│
├── 📂 guidelines/                  # الوثائق
│   └── Guidelines.md              # إرشادات التطوير
│
└── 📚 Documentation/               # الوثائق
    ├── README.md                  # هذا الملف
    ├── PROJECT_OVERVIEW.md        # نظرة شاملة
    ├── QUICK_START.md             # البدء السريع
    ├── REGISTRATION_GUIDE.md      # دليل التسجيل
    └── TASKS_DEPARTMENTS_GUIDE.md # دليل المهام
```

---

## 🎨 نظام التصميم

### 🎨 **لوحة الألوان**

<table>
<tr>
<td>
<img src="https://via.placeholder.com/50/1a73e8/1a73e8" alt="Primary"/>
</td>
<td><strong>Primary</strong><br/>#1a73e8</td>
<td>أزرق Google الرئيسي</td>
</tr>
<tr>
<td>
<img src="https://via.placeholder.com/50/34a853/34a853" alt="Secondary"/>
</td>
<td><strong>Secondary</strong><br/>#34a853</td>
<td>أخضر Google</td>
</tr>
<tr>
<td>
<img src="https://via.placeholder.com/50/fbbc04/fbbc04" alt="Warning"/>
</td>
<td><strong>Warning</strong><br/>#fbbc04</td>
<td>أصفر Google</td>
</tr>
<tr>
<td>
<img src="https://via.placeholder.com/50/ea4335/ea4335" alt="Danger"/>
</td>
<td><strong>Danger</strong><br/>#ea4335</td>
<td>أحمر Google</td>
</tr>
<tr>
<td>
<img src="https://via.placeholder.com/50/9334e9/9334e9" alt="Accent"/>
</td>
<td><strong>Accent</strong><br/>#9334e9</td>
<td>بنفسجي عصري</td>
</tr>
</table>

### ✨ **التأثيرات البصرية**

```css
/* الظلال */
shadow-custom-sm    → ظل خفيف
shadow-custom-md    → ظل متوسط
shadow-custom-lg    → ظل كبير
shadow-custom-xl    → ظل ضخم

/* المتدرجات */
bg-gradient-primary   → أزرق متدرج
bg-gradient-secondary → أخضر متدرج
bg-gradient-accent    → بنفسجي متدرج
bg-gradient-warm      → دافئ متدرج

/* التأثيرات */
glass-effect         → تأثير زجاجي
card-glow           → توهج البطاقة
hover-lift          → رفع عند Hover
scale-on-hover      → تكبير عند Hover
```

### 🎬 **الرسوم المتحركة**

```css
fade-in            → ظهور تدريجي
float              → حركة طفو
shimmer            → لمعان
pulse-slow         → نبض بطيء
animated-gradient  → متدرج متحرك
```

---

## 🔐 الحسابات التجريبية

### 🔴 **حساب المدير (Admin)**
```
البريد: admin@gdg.com
كلمة المرور: admin123

الصلاحيات:
✅ إدارة الفعاليات (إنشاء، تعديل، حذف)
✅ عرض التحليلات والإحصائيات
✅ إدارة الأقسام والمهام
✅ عرض تسجيلات الفعاليات
✅ جميع صلاحيات العضو
```

### 🟡 **حساب العضو (Member)**
```
البريد: member@gdg.com
كلمة المرور: member123

الصلاحيات:
✅ لوحة تحكم شخصية
✅ نظام Gamification كامل
✅ إدارة المهام الشخصية
✅ عرض الإحصائيات
✅ جميع صلاحيات المستخدم
```

### 🟢 **حساب المستخدم (User)**
```
البريد: user@gdg.com
كلمة المرور: user123

الصلاحيات:
✅ تصفح المحتوى
✅ عرض الفعاليات
✅ التسجيل في الفعاليات
✅ مشاهدة معلومات الفريق
```

---

## 📚 الوثائق

### 📖 **الدلائل الرسمية**

| الوثيقة | الوصف | الرابط |
|---------|--------|--------|
| 📘 نظرة عامة | معلومات شاملة عن المشروع | [PROJECT_OVERVIEW.md](PROJECT_OVERVIEW.md) |
| 🚀 البدء السريع | دليل الاستخدام للمبتدئين | [QUICK_START.md](QUICK_START.md) |
| 📝 دليل التسجيل | طرق التسجيل في الفعاليات | [REGISTRATION_GUIDE.md](REGISTRATION_GUIDE.md) |
| 🎯 دليل المهام | نظام الأقسام والمهام | [TASKS_DEPARTMENTS_GUIDE.md](TASKS_DEPARTMENTS_GUIDE.md) |
| 💻 إرشادات التطوير | للمطورين والمساهمين | [guidelines/Guidelines.md](guidelines/Guidelines.md) |

---

## 🚀 التطوير المستقبلي

### 📋 **الخطة القادمة**

#### **المرحلة 1: Backend Integration**
- [ ] ربط مع Supabase
- [ ] قاعدة بيانات PostgreSQL
- [ ] Authentication API
- [ ] Real-time subscriptions

#### **المرحلة 2: Enhanced Features**
- [ ] نظام الإشعارات (Email + Push)
- [ ] دردشة مباشرة
- [ ] نظام التقييمات
- [ ] مكتبة الموارد

#### **المرحلة 3: Mobile**
- [ ] تطبيق React Native
- [ ] دعم iOS و Android
- [ ] تزامن البيانات
- [ ] إشعارات الجوال

#### **المرحلة 4: Advanced Analytics**
- [ ] Machine Learning للتوصيات
- [ ] تحليلات تنبؤية
- [ ] تقارير مخصصة
- [ ] API للمطورين

---

## 🤝 المساهمة

نرحب بجميع المساهمات! 🎉

### كيف تساهم؟

1. **Fork المشروع** 🍴
2. **أنشئ فرع للميزة** 🌿
   ```bash
   git checkout -b feature/amazing-feature
   ```
3. **Commit التغييرات** 💾
   ```bash
   git commit -m 'Add amazing feature'
   ```
4. **Push للفرع** 🚀
   ```bash
   git push origin feature/amazing-feature
   ```
5. **افتح Pull Request** 📬

### قواعد المساهمة

- ✅ اتبع نمط الكود الحالي
- ✅ اكتب تعليقات واضحة
- ✅ اختبر التغييرات جيداً
- ✅ وثّق الميزات الجديدة
- ✅ تأكد من التوافق مع RTL

---

## 📄 الترخيص

هذا المشروع تم تطويره لـ **Google Developer Group - Future University**

جميع الحقوق محفوظة © 2025

---

## 📞 التواصل

<div align="center">

### تواصل معنا

📧 **البريد الإلكتروني**: gdg@futureuniversity.edu

🌐 **الموقع**: gdg.futureuniversity.edu

🐦 **تويتر**: [@GDG_FutureUni](https://twitter.com/GDG_FutureUni)

💼 **لينكد إن**: [GDG Future University](https://linkedin.com/company/gdg-future-university)

📱 **إنستغرام**: [@gdg_futureuni](https://instagram.com/gdg_futureuni)

</div>

---

## 🎉 شكر خاص

شكراً لجميع المساهمين والمطورين الذين ساهموا في إنجاح هذا المشروع!

### Built with ❤️ by:
**Google Developer Group - Future University Team**

---

<div align="center">

### ⭐ إذا أعجبك المشروع، لا تنسى إعطاءه نجمة!

![Made with Love](https://img.shields.io/badge/Made%20with-❤️-red?style=for-the-badge)
![Google](https://img.shields.io/badge/Google-Developer%20Group-4285f4?style=for-the-badge&logo=google)

**صُنع بـ ❤️ في جامعة المستقبل**

*آخر تحديث: نوفمبر 2025*

</div>
